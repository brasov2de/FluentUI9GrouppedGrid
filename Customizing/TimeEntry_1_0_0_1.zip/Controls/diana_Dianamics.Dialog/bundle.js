/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./Dialog/Open/custompage.ts":
/*!***********************************!*\
  !*** ./Dialog/Open/custompage.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.openCustomPage = void 0;\nfunction openCustomPage(context, callback) {\n  var _a, _b, _c, _d;\n  var entityName = context.parameters.entityName.raw;\n  var entityId = context.parameters.entityId.raw;\n  var width = (_a = context.parameters.width.raw) !== null && _a !== void 0 ? _a : \"500\";\n  var height = (_b = context.parameters.height.raw) !== null && _b !== void 0 ? _b : \"500\";\n  var position = (_c = context.parameters.position.raw) !== null && _c !== void 0 ? _c : \"Center\";\n  var name = (_d = context.parameters.pageName.raw) !== null && _d !== void 0 ? _d : \"\";\n  context.navigation.navigateTo({\n    pageType: \"custom\",\n    name: name,\n    entityId: entityId,\n    entityName: entityName !== null && entityName !== void 0 ? entityName : \"\"\n  }, {\n    width: {\n      value: parseInt(width),\n      unit: \"px\"\n    },\n    height: {\n      value: parseInt(height),\n      unit: \"px\"\n    },\n    position: position == \"Center\" ? 1 : 2,\n    target: 2 //dialog\n  }).then(function (value) {\n    var _a;\n    var entityReference = (_a = value.savedEntityReference) !== null && _a !== void 0 ? _a : [];\n    callback({\n      trigger: \"\",\n      values: entityReference\n    });\n  }).catch(console.error);\n}\nexports.openCustomPage = openCustomPage;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Dialog/Open/custompage.ts?");

/***/ }),

/***/ "./Dialog/Open/form.ts":
/*!*****************************!*\
  !*** ./Dialog/Open/form.ts ***!
  \*****************************/
/***/ (function(__unused_webpack_module, exports) {

eval("\n\nvar __assign = this && this.__assign || function () {\n  __assign = Object.assign || function (t) {\n    for (var s, i = 1, n = arguments.length; i < n; i++) {\n      s = arguments[i];\n      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];\n    }\n    return t;\n  };\n  return __assign.apply(this, arguments);\n};\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.openForm = void 0;\nfunction removeEmptyString(id) {\n  if (id == \"\") {\n    return null;\n  }\n  return id;\n}\nfunction openForm(context, callback) {\n  var _a, _b, _c, _d;\n  var entityName = context.parameters.entityName.raw;\n  var entityId = context.parameters.entityId.raw;\n  var width = (_a = context.parameters.width.raw) !== null && _a !== void 0 ? _a : \"500\";\n  var height = (_b = context.parameters.height.raw) !== null && _b !== void 0 ? _b : \"500\";\n  var position = (_c = context.parameters.position.raw) !== null && _c !== void 0 ? _c : \"Center\";\n  var dataString = removeEmptyString((_d = context.parameters.data) === null || _d === void 0 ? void 0 : _d.raw);\n  var dataParam = {};\n  try {\n    if (dataString != null) {\n      dataParam = {\n        data: JSON.parse(dataString !== null && dataString !== void 0 ? dataString : \"{}\")\n      };\n    }\n  } catch (e) {\n    console.error(e);\n  }\n  var formIdString = removeEmptyString(context.parameters.formId.raw);\n  var tabNameString = removeEmptyString(context.parameters.formTabName.raw);\n  var formIdParam = formIdString != null ? {\n    formId: formIdString\n  } : {};\n  var tabNameParam = tabNameString != null ? {\n    tabName: tabNameString\n  } : {};\n  context.navigation.navigateTo(__assign(__assign(__assign({\n    pageType: \"entityrecord\",\n    entityId: removeEmptyString(entityId),\n    entityName: entityName !== null && entityName !== void 0 ? entityName : \"\"\n  }, dataParam), formIdParam), tabNameParam), {\n    width: {\n      value: parseInt(width),\n      unit: \"px\"\n    },\n    height: {\n      value: parseInt(height),\n      unit: \"px\"\n    },\n    position: position == \"Center\" ? 1 : 2,\n    target: 2 //dialog\n  }).then(function (value) {\n    var _a;\n    var entityReference = (_a = value.savedEntityReference) !== null && _a !== void 0 ? _a : [];\n    callback({\n      trigger: \"\",\n      values: entityReference\n    });\n  }).catch(console.error);\n}\nexports.openForm = openForm;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Dialog/Open/form.ts?");

/***/ }),

/***/ "./Dialog/StaticData.ts":
/*!******************************!*\
  !*** ./Dialog/StaticData.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.ResultData = exports.ResultSchema = void 0;\nexports.ResultSchema = {\n  \"$schema\": \"http://json-schema.org/draft-04/schema#\",\n  \"type\": \"object\",\n  \"properties\": {\n    \"trigger\": {\n      \"type\": \"string\"\n    },\n    \"values\": {\n      \"type\": \"array\",\n      \"items\": {\n        \"type\": \"object\",\n        \"properties\": {\n          \"id\": {\n            \"type\": \"string\"\n          },\n          \"entityType\": {\n            \"type\": \"string\"\n          },\n          \"name\": {\n            \"type\": \"string\"\n          }\n        }\n      }\n    }\n  }\n};\nexports.ResultData = {\n  trigger: \"\",\n  values: [{\n    id: \"79084197-d55b-47fd-a411-15ad1fceb912\",\n    entityType: \"account\",\n    name: \"Coffee House\"\n  }]\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Dialog/StaticData.ts?");

/***/ }),

/***/ "./Dialog/index.ts":
/*!*************************!*\
  !*** ./Dialog/index.ts ***!
  \*************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\n\nvar __awaiter = this && this.__awaiter || function (thisArg, _arguments, P, generator) {\n  function adopt(value) {\n    return value instanceof P ? value : new P(function (resolve) {\n      resolve(value);\n    });\n  }\n  return new (P || (P = Promise))(function (resolve, reject) {\n    function fulfilled(value) {\n      try {\n        step(generator.next(value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function rejected(value) {\n      try {\n        step(generator[\"throw\"](value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function step(result) {\n      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);\n    }\n    step((generator = generator.apply(thisArg, _arguments || [])).next());\n  });\n};\nvar __generator = this && this.__generator || function (thisArg, body) {\n  var _ = {\n      label: 0,\n      sent: function sent() {\n        if (t[0] & 1) throw t[1];\n        return t[1];\n      },\n      trys: [],\n      ops: []\n    },\n    f,\n    y,\n    t,\n    g;\n  return g = {\n    next: verb(0),\n    \"throw\": verb(1),\n    \"return\": verb(2)\n  }, typeof Symbol === \"function\" && (g[Symbol.iterator] = function () {\n    return this;\n  }), g;\n  function verb(n) {\n    return function (v) {\n      return step([n, v]);\n    };\n  }\n  function step(op) {\n    if (f) throw new TypeError(\"Generator is already executing.\");\n    while (g && (g = 0, op[0] && (_ = 0)), _) try {\n      if (f = 1, y && (t = op[0] & 2 ? y[\"return\"] : op[0] ? y[\"throw\"] || ((t = y[\"return\"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;\n      if (y = 0, t) op = [op[0] & 2, t.value];\n      switch (op[0]) {\n        case 0:\n        case 1:\n          t = op;\n          break;\n        case 4:\n          _.label++;\n          return {\n            value: op[1],\n            done: false\n          };\n        case 5:\n          _.label++;\n          y = op[1];\n          op = [0];\n          continue;\n        case 7:\n          op = _.ops.pop();\n          _.trys.pop();\n          continue;\n        default:\n          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {\n            _ = 0;\n            continue;\n          }\n          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {\n            _.label = op[1];\n            break;\n          }\n          if (op[0] === 6 && _.label < t[1]) {\n            _.label = t[1];\n            t = op;\n            break;\n          }\n          if (t && _.label < t[2]) {\n            _.label = t[2];\n            _.ops.push(op);\n            break;\n          }\n          if (t[2]) _.ops.pop();\n          _.trys.pop();\n          continue;\n      }\n      op = body.call(thisArg, _);\n    } catch (e) {\n      op = [6, e];\n      y = 0;\n    } finally {\n      f = t = 0;\n    }\n    if (op[0] & 5) throw op[1];\n    return {\n      value: op[0] ? op[1] : void 0,\n      done: true\n    };\n  }\n};\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.Dialog = void 0;\nvar React = __webpack_require__(/*! react */ \"react\");\nvar StaticData_1 = __webpack_require__(/*! ./StaticData */ \"./Dialog/StaticData.ts\");\nvar form_1 = __webpack_require__(/*! ./Open/form */ \"./Dialog/Open/form.ts\");\nvar custompage_1 = __webpack_require__(/*! ./Open/custompage */ \"./Dialog/Open/custompage.ts\");\nvar Dialog = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function Dialog() {\n    this.result = StaticData_1.ResultData;\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  Dialog.prototype.init = function (context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  };\n  Dialog.prototype.afterClose = function (result) {\n    var _a, _b;\n    this.result = result;\n    this.result.trigger = (_b = (_a = this.trigger) === null || _a === void 0 ? void 0 : _a.toString()) !== null && _b !== void 0 ? _b : \"\";\n    this.notifyOutputChanged();\n  };\n  Dialog.prototype.openDialog = function (context, callback) {\n    console.log(\"Open Dialog now\", context);\n    if (context.parameters.type.raw === \"Form\") {\n      (0, form_1.openForm)(context, callback);\n    }\n    if (context.parameters.type.raw === \"CustomPage\") {\n      (0, custompage_1.openCustomPage)(context, callback);\n    }\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  Dialog.prototype.updateView = function (context) {\n    if (this.trigger !== context.parameters.dialogTrigger.raw && context.parameters.dialogTrigger.raw != null && context.parameters.dialogTrigger.raw != \"\") {\n      this.trigger = context.parameters.dialogTrigger.raw;\n      if (context.updatedProperties.includes(\"dialogTrigger\")) {\n        this.openDialog(context, this.afterClose.bind(this));\n      }\n    }\n    return React.createElement(React.Fragment);\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  Dialog.prototype.getOutputs = function () {\n    console.log(\"---passing result---\", this.result);\n    return {\n      result: this.result\n    };\n  };\n  Dialog.prototype.getOutputSchema = function (context) {\n    return __awaiter(this, void 0, void 0, function () {\n      return __generator(this, function (_a) {\n        return [2 /*return*/, Promise.resolve({\n          result: StaticData_1.ResultSchema\n        })];\n      });\n    });\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  Dialog.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return Dialog;\n}();\nexports.Dialog = Dialog;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Dialog/index.ts?");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./Dialog/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Dianamics.Dialog', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.Dialog);
} else {
	var Dianamics = Dianamics || {};
	Dianamics.Dialog = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.Dialog;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}